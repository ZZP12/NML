function find_sentence_type_of_all_sentences(input_Sentence_Array::Array{sentenceObjectWithType,1}, unusual_chars_error_messenges::Array{errorObject,1})
  if !isempty(unusual_chars_error_messenges)
    println("\n\n============unusual chars===========")
    for error in unusual_chars_error_messenges
      println("at line $(error.lineNumber) \""*error.errorSentence*"\" at $(error.columnNumber)")
    end
    return 1
  elseif !isempty(input_Sentence_Array)
    invalid_sentence_counter = 0
    # identify type of each sentence
    println("\n\n=========type undefined sentence=======================")
    for sentence in input_Sentence_Array
      sentenceType = find_action_type_of_a_sentence(sentence)
      if sentenceType == "invalid sentence type"
        invalid_sentence_counter += 1
        println("line $(sentence.sentenceNo) is \""*sentenceType*"\" --> "*(sentence.originalSentence))
      else
        sentence.actionType = sentenceType
      end
    end
    return invalid_sentence_counter
  else
    println("\n\nThe file path $path_to_model_file leads to a file that does not contain any valid sentence")
    return 1
  end
end


function load_model_statements(path_to_model_file::String)
  # take in model file path,
  # split models into sentences with line number, check for unusual char in each sentence & comma at the end
  input_Sentence_Array = sentenceObjectWithType[]
  unusual_chars_error_messenges = errorObject[]
  lineNumberCounter::Int = 0
  try
    # open model file and load line-by-line
    open(path_to_model_file, "r") do model_file
      for eachSentence in eachline(model_file)
        lineNumberCounter += 1
        if ((contains(eachSentence, "//") == false) && (eachSentence[1] != '\n'))
          eachSentence = chomp(eachSentence)
          if eachSentence[end] == ';'
            tmp_sentence_object = sentenceObjectWithType()
            tmp_sentence_object.originalSentence = eachSentence
            tmp_sentence_object.sentenceNo = lineNumberCounter
            # check for unusual chars
            column_number = search(tmp_sentence_object.originalSentence, r"[\%\@\!\$]")
            # only can return the first unusual char, how can return all chars? can do this w/o using regex
            if isempty(column_number)

            else
              error_message = errorObject()
              error_message.errorSentence = "invalid charts found"
              error_message.lineNumber = tmp_sentence_object.sentenceNo
              error_message.columnNumber = collect(column_number)
              push!(unusual_chars_error_messenges, error_message)
            end
            #? what will happen if return nothing? ==> Void
            push!(input_Sentence_Array, tmp_sentence_object)
          else
            error_message = errorObject()
            error_message.errorSentence = "missing comma at the end"
            error_message.lineNumber = lineNumberCounter
            error_message.columnNumber = [1, endof(eachSentence)]
            push!(unusual_chars_error_messenges, error_message)
          end
        end
      end
    end
  catch err
    showerror(STDOUT, err, backtrace());println()
  end
  return (input_Sentence_Array, unusual_chars_error_messenges)
end

function find_action_type_of_a_sentence(input_Sentence::sentenceObjectWithType)
  # take in sentence object
  # return sentence type as a Stirng: invalid sentence or valid types
  # arrange scenarios in order of occurrence probability can promote running speed
  if !isempty(search(input_Sentence.originalSentence, r" equal(s|ed|ing)? to | = | is TAG| is \_|\) are \("))
    # symbol assignment
    verb_index = collect(search(input_Sentence.originalSentence, r" equals? to | = | is TAG| is \_|\) are \("))
    sentenceType = "symbol assignment"
  elseif !isempty(search(input_Sentence.originalSentence, r" react(s|ed|ing)? into "))
    # react
    sentenceType = "react"
  elseif !isempty(search(input_Sentence.originalSentence, r" phosphorylat(e|es|ed|ing) "))
    # phosphorylate
    sentenceType = "phosphorylate"
  elseif !isempty(search(input_Sentence.originalSentence, r" dephosphorylat(e|es|ed|ing) "))
    # dephosphorylate
    sentenceType = "dephosphorylate"
  elseif !isempty(search(input_Sentence.originalSentence, r" cataly(z|s)(e|es|ed|ing) "))
    # catalyze
    sentenceType = "catalyze"
  elseif !isempty(search(input_Sentence.originalSentence, r" (upregulat|promot|activat)(e|es|ed|ing) "))
    # activate
    sentenceType = "activate"
  elseif !isempty(search(input_Sentence.originalSentence, r" ((downregulat|deactivat)(e|es|ed|ing)|repress(es|ed|ing)?|inhibit(s|ed|ing)?) "))
    # inhibit
    sentenceType = "inhibit"
  elseif !isempty(search(input_Sentence.originalSentence, r"(t|T)he cell (uptak(e|es|ing)|uptook) "))
    # uptakeuptake
    sentenceType = "uptake"
  elseif !isempty(search(input_Sentence.originalSentence, r"(t|T)he cell secret(e|es|ed|ing) "))
    # secrete
    sentenceType = "secrete"
  elseif !isempty(search(input_Sentence.originalSentence, r" translocat(e|es|ed|ing) (into|out of) "))
    # translocate into
    sentenceType = "translocate"
  elseif !isempty(search(input_Sentence.originalSentence, r" (bind(s|ing)?|bound|associat(e|es|ed|ing)|complex(es|ed|ing)?)( |;)"))
    # bind
    sentenceType = "bind"
  elseif !isempty(search(input_Sentence.originalSentence, r" (unbind(s|ing)?|unbound|disassociat(e|es|ed|ing));"))
    # unbind
    sentenceType = "unbind"
  elseif !isempty(search(input_Sentence.originalSentence, r" splic(e|es|ed|ing) into "))
    # splice
    sentenceType = "splice"
  elseif !isempty(search(input_Sentence.originalSentence, r" ubiquitinat(e|es|ed|ing|ion) "))
    # ubiquitinate
    verb_index = collect(search(input_Sentence.originalSentence, r" ubiquitinat(e|es|ed|ing|ion) "))
    sentenceType = "ubiquitinate"
  elseif !isempty(search(input_Sentence.originalSentence, r" deubiquitinat(e|es|ed|ing|ion) "))
    # deubiquitinate
    verb_index = collect(search(input_Sentence.originalSentence, r" deubiquitinat(e|es|ed|ing|ion) "))
    sentenceType = "deubiquitinate"
  elseif !isempty(search(input_Sentence.originalSentence, r" acetylat(e|es|ed|ing|ion) "))
    # acetylate
    verb_index = collect(search(input_Sentence.originalSentence, r" acetylat(e|es|ed|ing|ion) "))
    sentenceType = "acetylate"
  elseif !isempty(search(input_Sentence.originalSentence, r" deacetylat(e|es|ed|ing|ion) "))
    # deacetylate
    verb_index = collect(search(input_Sentence.originalSentence, r" deacetylat(e|es|ed|ing|ion) "))
    sentenceType = "deacetylate"
  else
    sentenceType = "invalid sentence type"
  end
  return sentenceType
end

function set_up_symbol_conversion_dict(input_Sentence_Array::Array{sentenceObjectWithType,1}, reservedWords::Set{String})
  # return "symbol_conversion_dict = Dict{String,String}()""  #user ==> system
  # symbol_conv_grammar_error
  # the last char is ";"
  symbol_conversion_dict = Dict{String,String}()
  symbol_conv_grammar_error = errorObject[]
  for input_Sentence in input_Sentence_Array
    if input_Sentence.actionType == "symbol assignment"
      # distinguish multiple & single by ")...("
      verbPhrase_index = collect(search(input_Sentence.originalSentence, r"\) (equal(ed|ing)? to|=|are) \("))
      #single
      if isempty(verbPhrase_index)
        verbPhrase_index = collect(search(input_Sentence.originalSentence, r" (equal(s|ed|ing) to|=|is) "))
        actor_string = input_Sentence.originalSentence[1:verbPhrase_index[1]-1]
        target_string = input_Sentence.originalSentence[verbPhrase_index[end]+1:end-1]
        if isempty(actor_string)|isempty(target_string)
          # empty symbol
          tmp_error = errorObject()
          tmp_error.columnNumber = [1, endof(input_Sentence.originalSentence)]
          tmp_error.errorSentence = "empty symbol is not allowed -->"*input_Sentence.originalSentence
          tmp_error.lineNumber = input_Sentence.sentenceNo
          push!(symbol_conv_grammar_error, tmp_error)
        elseif !in(target_string, reservedWords)
          #non-reserved words
          tmp_error = errorObject()
          tmp_error.columnNumber = [1, endof(input_Sentence.originalSentence)]
          tmp_error.errorSentence = "non-reserved words -->"*input_Sentence.originalSentence
          tmp_error.lineNumber = input_Sentence.sentenceNo
          push!(symbol_conv_grammar_error, tmp_error)
        else
          symbol_conversion_dict[actor_string] = target_string
        end

      # multiple
      else
        verbPhrase_index = collect(search(input_Sentence.originalSentence, r" (equal(ed|ing)? to|=|are) "))
        errorcounter = 0
        if (input_Sentence.originalSentence[1]!='(')|(input_Sentence.originalSentence[end-1]!=')')|(input_Sentence.originalSentence[verbPhrase_index[1]-1]!=')')|(input_Sentence.originalSentence[verbPhrase_index[end]+1]!='(')
          # does not find two paris of parentheses, the last char is "comma"
          tmp_error = errorObject()
          tmp_error.columnNumber = [1, endof(input_Sentence.originalSentence)]
          tmp_error.errorSentence = "not start with '(' or end w/ ')' -->"*input_Sentence.originalSentence
          tmp_error.lineNumber = input_Sentence.sentenceNo
          push!(symbol_conv_grammar_error, tmp_error)
        else
          actor_string = input_Sentence.originalSentence[2:verbPhrase_index[1]-2]
          if isempty(actor_string) #check chars of actor
            tmp_error = errorObject()
            tmp_error.columnNumber = collect(1:verbPhrase_index[1]-1)
            tmp_error.errorSentence = "no symbol found -->"*input_Sentence.originalSentence
            tmp_error.lineNumber = input_Sentence.sentenceNo
            push!(symbol_conv_grammar_error, tmp_error)
            errorcounter += 1
          else
            actor_string = replace(actor_string, r",|and|&|or|\|", " ")
            actor_string_array = split(actor_string)
          end
          target_string = input_Sentence.originalSentence[verbPhrase_index[end]+2:end-2]
          if isempty(target_string) # check chars of target
            tmp_error = errorObject()
            tmp_error.columnNumber = collect(verbPhrase_index[end]+1:endof(input_Sentence.originalSentence))
            tmp_error.errorSentence = "no symbol found -->"*input_Sentence.originalSentence
            tmp_error.lineNumber = input_Sentence.sentenceNo
            push!(symbol_conv_grammar_error, tmp_error)
            errorcounter += 1
          else
            target_string = replace(target_string, r",|and|&|or|\|", " ")
            target_string_array = split(target_string)
          end
          if errorcounter == 0  # both actor and target are valid
            if length(actor_string_array) == length(target_string_array)
              for i = 1:length(actor_string_array)
                if in(target_string_array[i], reservedWords)
                  symbol_conversion_dict[actor_string_array[i]] = target_string_array[i]
                else
                  tmp_error = errorObject()
                  tmp_error.columnNumber = [1, endof(input_Sentence.originalSentence)]
                  tmp_error.errorSentence = "non-reserved words -->"*input_Sentence.originalSentence
                  tmp_error.lineNumber = input_Sentence.sentenceNo
                  push!(symbol_conv_grammar_error, tmp_error)
                end
              end
            else   # unequal number --> error
              tmp_error.columnNumber = [1, endof(input_Sentence.originalSentence)]
              tmp_error.errorSentence = "unequal numbers of symbols -->"*input_Sentence.originalSentence
              tmp_error.lineNumber = input_Sentence.sentenceNo
              push!(symbol_conv_grammar_error, tmp_error)
            end
          end

        end
      end
    end
  end

  return (symbol_conversion_dict, symbol_conv_grammar_error)
end

function tokenize_all_sentence(input_Sentence_Array::Array{sentenceObjectWithType,1})
  # taken in sentence object Array, tokenize all sentence
  # return problem_tokens_array {array of any}? {array of arrays}
  # return error_while_tokenizing_sentence
  tokenized_sentence_array = Array{tokenizedSentence,1}()
  error_while_tokenizing_sentence = Array{errorObject,1}()
  for input_Sentence in input_Sentence_Array
    if input_Sentence.actionType == "react"
      create_react_AST(input_Sentence, tokenized_sentence_array, error_while_tokenizing_sentence)
    elseif input_Sentence.actionType == "activate"
      create_activate_AST(input_Sentence, tokenized_sentence_array, error_while_tokenizing_sentence)
    elseif input_Sentence.actionType == "inhibit"
      create_inhibit_AST(input_Sentence, tokenized_sentence_array, error_while_tokenizing_sentence)
    elseif input_Sentence.actionType == "translocate"
      create_translocate_AST(input_Sentence, tokenized_sentence_array, error_while_tokenizing_sentence)
    elseif input_Sentence.actionType == "uptake"
      create_uptake_AST(input_Sentence, tokenized_sentence_array, error_while_tokenizing_sentence)
    elseif input_Sentence.actionType == "secrete"
      create_secrete_AST(input_Sentence, tokenized_sentence_array, error_while_tokenizing_sentence)
    elseif input_Sentence.actionType == "bind"
      create_bind_AST(input_Sentence, tokenized_sentence_array, error_while_tokenizing_sentence)
    elseif input_Sentence.actionType == "unbind"
      create_unbind_AST(input_Sentence, tokenized_sentence_array, error_while_tokenizing_sentence)
    elseif input_Sentence.actionType == "splice"
      create_splice_AST(input_Sentence, tokenized_sentence_array, error_while_tokenizing_sentence)
    elseif input_Sentence.actionType == "phosphorylate"
      create_phosphorylate_AST(input_Sentence, tokenized_sentence_array, error_while_tokenizing_sentence)
    elseif input_Sentence.actionType == "dephosphorylate"
      create_dephosphorylate_AST(input_Sentence, tokenized_sentence_array, error_while_tokenizing_sentence)
    elseif input_Sentence.actionType == "catalyze"
      create_catalyze_AST(input_Sentence, tokenized_sentence_array, error_while_tokenizing_sentence)
    else
      #other cases
    end
  end
  return (tokenized_sentence_array, error_while_tokenizing_sentence)
end
