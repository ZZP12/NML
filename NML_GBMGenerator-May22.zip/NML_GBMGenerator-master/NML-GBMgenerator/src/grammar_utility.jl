function tokenize_and_or_logic_string(actor_string::String, column::Array{Int,1}, line::Int, actor_token_array::Array{Array{TokenObject,1},1}, tmp_tokenized_error_array::Array{errorObject,1})
  #take in string, using rule "and > or, but not ()"
  if !isempty(search(actor_string, r"\(|\)")) # has ()
    tmp_error = errorObject()
    tmp_error.errorSentence = "both \"(\" and \")\" are not allowed"
    tmp_error.columnNumber = column
    tmp_error.lineNumber = line
    push!(tmp_tokenized_error_array, tmp_error)
  else # does not have ()
    if length(split(actor_string))== 0
      tmp_error = errorObject()
      tmp_error.errorSentence = "empty symbol"
      tmp_error.columnNumber = column
      tmp_error.lineNumber = line
      push!(tmp_tokenized_error_array, tmp_error)
    else # non-empty
      actor_string_array = split(actor_string, r" or |\|")
      for sub_string in actor_string_array
        if isempty(search(sub_string, r" and |&|,")) #single symbol
          sub_string = replace(sub_string, " ", "")
          if (length(split(sub_string, '_')) < 2)  #type undefined symbol (should at least be 2, can have suffix)
            tmp_error = errorObject()
            tmp_error.errorSentence = "\"$sub_string\" undefined symbol type"
            tmp_error.columnNumber = column
            tmp_error.lineNumber = line
            push!(tmp_tokenized_error_array, tmp_error)
          else   # save tokens outside(), may only contain incomplete information
            tmp_token_array = TokenObject[]
            tmp_token = TokenObject()
            tmp_token.tokenName = sub_string
            tmp_token.tokenType = split(sub_string, '_')[1]
            push!(tmp_token_array, tmp_token)
            push!(actor_token_array, tmp_token_array)
          end
        else # has "&"
          sub_string = replace(sub_string, r" and |&|,", " ")
          sub_string_array = split(sub_string) #split & concatenate
          tmp_token_array = TokenObject[]
          for sub_sub_string in sub_string_array
            if length(split(sub_sub_string, '_')) < 2  #type undefined symbol
              tmp_error = errorObject()
              tmp_error.errorSentence = "no fully defined symbol found inside ()"
              tmp_error.columnNumber = column
              tmp_error.lineNumber = line
              push!(tmp_tokenized_error_array, tmp_error)
            else  # found a symbol
              tmp_token = TokenObject()
              tmp_token.tokenName = sub_sub_string
              tmp_token.tokenType = split(sub_sub_string, '_')[1]
              push!(tmp_token_array, tmp_token)
            end
          end
          push!(actor_token_array, tmp_token_array) # save tokens
        end
      end
    end
  end
end


function tokenize_parentheses_and_logic_string(actor_string::String, column::Array{Int,1}, line::Int, actor_token_array::Array{Array{TokenObject,1},1}, tmp_tokenized_error_array::Array{errorObject,1})
  # take in string, using rule "() > and, but not or"
  if !isempty(search(actor_string, r" or |\|")) # has "or"
    tmp_error = errorObject()
    tmp_error.errorSentence = "logic \"or\" are not allowed"
    tmp_error.columnNumber = column
    tmp_error.lineNumber = line
    push!(tmp_tokenized_error_array, tmp_error)
  else # does not have "or"
    if  length(split(actor_string)) == 0 # empty
      tmp_error = errorObject()
      tmp_error.errorSentence = "empty symbol"
      tmp_error.columnNumber = column
      tmp_error.lineNumber = line
      push!(tmp_tokenized_error_array, tmp_error)
    else # non empty
      actor_string = replace(actor_string, r",| and |&", " ")
      #process parentheses ()
      while(!isempty(search(actor_string, r"\(|\)")))  #process parentheses ()
        #process parentheses ()
        left_index = search(actor_string, '(')
        right_index = search(actor_string, ')')
        if (left_index == 0)||(right_index == 0)||(right_index < left_index) # unpaired ()
          # unpaired ()
          tmp_error = errorObject()
          tmp_error.errorSentence = "unpaired or mispaired ()"
          tmp_error.columnNumber = column
          tmp_error.lineNumber = line
          push!(tmp_tokenized_error_array, tmp_error)
          actor_string = replace(actor_string, r"\(|\)", " ") #break out of "while"
        else # paired, non-empty, but may contain '('
          sub_actor_string = actor_string[left_index+1:right_index-1]  # extract string inside parentheses
          actor_string = replace(actor_string, actor_string[left_index:right_index], " ") # update actor_string
          if isempty(search(sub_actor_string, r"\(|\)"))  # tokenizing symbols inside()
            # tokenizing symbols inside()
            sub_actor_string_array = split(sub_actor_string)
            tmp_token_array = TokenObject[]
            for sub_string in sub_actor_string_array
              if length(split(sub_string, '_')) < 2  #type undefined symbol
                tmp_error = errorObject()
                tmp_error.errorSentence = "no fully defined symbol found inside ()"
                tmp_error.columnNumber = column
                tmp_error.lineNumber = line
                push!(tmp_tokenized_error_array, tmp_error)
              else  # found a symbol
                tmp_token = TokenObject()
                tmp_token.tokenName = sub_string
                tmp_token.tokenType = split(sub_string, '_')[1]
                push!(tmp_token_array, tmp_token)
              end
            end
            push!(actor_token_array, tmp_token_array) # save tokens inside (), may be empty or only contain incomplete information
          else  # more than one level of ()
            tmp_error = errorObject()
            tmp_error.errorSentence = "only one level of \"()\" is allowed"
            tmp_error.columnNumber = column
            tmp_error.lineNumber = line
            push!(tmp_tokenized_error_array, tmp_error)
          end
        end
      end
      # now, processing symbols outside parentheses
      actor_string_array = split(actor_string)
      for sub_string in actor_string_array
        if (length(split(sub_string, '_')) < 2)  #type undefined symbol
          tmp_error = errorObject()
          tmp_error.errorSentence = "no fully defined symbol found outside ()"
          tmp_error.columnNumber = column
          tmp_error.lineNumber = line
          push!(tmp_tokenized_error_array, tmp_error)
        else   # found a symbol
          tmp_token_array = TokenObject[]
          tmp_token = TokenObject()
          tmp_token.tokenName = sub_string
          tmp_token.tokenType = split(sub_string, '_')[1]
          push!(tmp_token_array, tmp_token)
          push!(actor_token_array, tmp_token_array)
        end
      end
    end
  end
end


# arguments for function: processing object, source of object(column, line), space for results, space for errors
function tokenize_symbols_with_stoichiometry_string(product_string::String, column::Array{Int,1}, line::Int, product_token_array::Array{coTokenObject,1}, tmp_tokenized_error_array::Array{errorObject,1})
  #
  if length(split(product_string)) == 0   # empty symbol
    tmp_error = errorObject()
    tmp_error.errorSentence = "empty symbol"
    tmp_error.columnNumber = column
    tmp_error.lineNumber = line
    push!(tmp_tokenized_error_array, tmp_error)
  else # non-empty
    if !isempty(search(product_string, r" or |\||\(|\)")) # has logic "or" or "()"
      tmp_error = errorObject()
      tmp_error.errorSentence = "both logic \"()\" and \"or\" are not allowed"
      tmp_error.columnNumber = column
      tmp_error.lineNumber = line
      push!(tmp_tokenized_error_array, tmp_error)
    else # only has logic "&"
      product_string = replace(product_string, r" and |&|,", " ")
      product_string_array = split(product_string)
      for sub_string in product_string_array
        if (length(split(sub_string, '*')) > 2)  # no '*' or too many '*'
          tmp_error = errorObject()
          tmp_error.errorSentence = "\"$sub_string\" has more than one \"*\""
          tmp_error.columnNumber = column
          tmp_error.lineNumber = line
          push!(tmp_tokenized_error_array, tmp_error)
        elseif (length(split(sub_string, '*')) == 1) # no '*'
          tmp_token = coTokenObject()
          tmp_token.tokenCoefficient = 1.0
          tmp_token.tokenName = sub_string
          if (length(split(tmp_token.tokenName, '_')) < 2)  #type undefined symbol (should at least be 2, can have suffix)
            tmp_error = errorObject()
            tmp_error.errorSentence = "\"$(tmp_token.tokenName)\" is an imcomplete symbol"
            tmp_error.columnNumber = column
            tmp_error.lineNumber = line
            push!(tmp_tokenized_error_array, tmp_error)
          else   #has type
            tmp_token.tokenType = split(tmp_token.tokenName, '_')[1]
            push!(product_token_array, tmp_token)
          end
        else   # only one "*"
          tmp_token = coTokenObject()
          if isnull(tryparse(Float64, split(sub_string, '*')[1])) # fail to change String into Float
            tmp_error = errorObject()
            tmp_error.errorSentence = "\"$sub_string\" has invalid coefficient"
            tmp_error.columnNumber = column
            tmp_error.lineNumber = line
            push!(tmp_tokenized_error_array, tmp_error)
          else # get the coefficient
            tmp_token.tokenCoefficient = get(tryparse(Float64, split(sub_string, '*')[1]))
            tmp_token.tokenName = split(sub_string, '*')[2]
            if (length(split(tmp_token.tokenName, '_')) < 2)  #type undefined symbol (should at least be 2, can have suffix)
              tmp_error = errorObject()
              tmp_error.errorSentence = "\"$(tmp_token.tokenName)\" is an imcomplete symbol"
              tmp_error.columnNumber = column
              tmp_error.lineNumber = line
              push!(tmp_tokenized_error_array, tmp_error)
            else   #has type
              tmp_token.tokenType = split(tmp_token.tokenName, '_')[1]
              push!(product_token_array, tmp_token)
            end
          end
        end
      end
    end
  end
end


function tokenize_only_one_legal_symbol_string(target_string::String, column::Array{Int,1}, line::Int, target_token::TokenObject, tmp_tokenized_error_array::Array{errorObject,1})
  #take in string, using rule "only one symbol is allowed"
  if !isempty(search(target_string, r" and |&|,| or |\||\(|\)")) # other logic
    tmp_error = errorObject()
    tmp_error.errorSentence = "only one symbol is allowed"
    tmp_error.columnNumber = column
    tmp_error.lineNumber = line
    push!(tmp_tokenized_error_array, tmp_error)
  else # only one symbol
    target_string_array = split(target_string)
    if length(target_string_array) != 1  # target is missing or written inappropriately
      tmp_error = errorObject()
      tmp_error.errorSentence = "target is missing or written with \" \""
      tmp_error.columnNumber = column
      tmp_error.lineNumber = line
      push!(tmp_tokenized_error_array, tmp_error)
    else
      if (length(split(target_string_array[1], '_')) < 2)  #type undefined symbol (should at least be 2, can have suffix)
        tmp_error = errorObject()
        tmp_error.errorSentence = "\"$(target_string_array[1])\" is an imcomplete symbol"
        tmp_error.columnNumber = column
        tmp_error.lineNumber = line
        push!(tmp_tokenized_error_array, tmp_error)
      else   # complete symbol
        target_token.tokenName = target_string_array[1]
        target_token.tokenType = split(target_string_array[1], '_')[1]
      end
    end
  end
end

function tokenize_and_or_logic_string_with_brackets(actor_string::String, column::Array{Int,1}, line::Int, actor_token_array::Array{Array{TokenObject,1},1}, tmp_tokenized_error_array::Array{errorObject,1})
  #take in string, using rule "and > or, but not ()"
  # detect "[]", token type is EMPTY, but only one "[]" is allowed
  if !isempty(search(actor_string, r"\(|\)")) # has ()
    tmp_error = errorObject()
    tmp_error.errorSentence = "both \"(\" and \")\" are not allowed"
    tmp_error.columnNumber = column
    tmp_error.lineNumber = line
    push!(tmp_tokenized_error_array, tmp_error)
  else # does not have ()
    if length(split(actor_string))== 0  # empty
      tmp_error = errorObject()
      tmp_error.errorSentence = "empty symbol"
      tmp_error.columnNumber = column
      tmp_error.lineNumber = line
      push!(tmp_tokenized_error_array, tmp_error)
    else # non-empty
      actor_string_array = split(actor_string, r" or |\|")
      brackets_marker = true
      for sub_string in actor_string_array
        if isempty(search(sub_string, r" and |&|,")) #single symbol
          sub_string = replace(sub_string, " ", "") #concatenate
          if (sub_string == "[]") && (brackets_marker) # find the 1st "[]"
            tmp_token_array = TokenObject[]
            tmp_token = TokenObject()
            tmp_token.tokenName = sub_string
            tmp_token.tokenType = "EMPTY"
            brackets_marker = false
            push!(tmp_token_array, tmp_token)
            push!(actor_token_array, tmp_token_array)
          elseif (sub_string == "[]") && (!brackets_marker) # find other "[]"
            tmp_error = errorObject()
            tmp_error.errorSentence = "\"$sub_string\" is repeated \"[]\""
            tmp_error.columnNumber = column
            tmp_error.lineNumber = line
            push!(tmp_tokenized_error_array, tmp_error)
          elseif (length(split(sub_string, '_')) < 2)  #type undefined symbol (should at least be 2, can have suffix)
            tmp_error = errorObject()
            tmp_error.errorSentence = "\"$sub_string\" undefined symbol type"
            tmp_error.columnNumber = column
            tmp_error.lineNumber = line
            push!(tmp_tokenized_error_array, tmp_error)
          else   # save tokens
            tmp_token_array = TokenObject[]
            tmp_token = TokenObject()
            tmp_token.tokenName = sub_string
            tmp_token.tokenType = split(sub_string, '_')[1]
            push!(tmp_token_array, tmp_token)
            push!(actor_token_array, tmp_token_array)
          end
        else # has "&"
          sub_string = replace(sub_string, r" and |&|,", " ")
          sub_string_array = split(sub_string) #split & concatenate
          tmp_token_array = TokenObject[]
          sub_brackets = true
          for sub_sub_string in sub_string_array
            if (sub_sub_string == "[]") && (sub_brackets) # find the 1st "[]"
              tmp_token = TokenObject()
              tmp_token.tokenName = sub_sub_string
              tmp_token.tokenType = "EMPTY"
              sub_brackets = false
              push!(tmp_token_array, tmp_token)
            elseif (sub_sub_string == "[]") && (!sub_brackets) # find other "[]"
              tmp_error = errorObject()
              tmp_error.errorSentence = "\"$sub_sub_string\" is repeated \"[]\""
              tmp_error.columnNumber = column
              tmp_error.lineNumber = line
              push!(tmp_tokenized_error_array, tmp_error)
            elseif (length(split(sub_sub_string, '_')) < 2)  #type undefined symbol (should at least be 2, can have suffix)
              tmp_error = errorObject()
              tmp_error.errorSentence = "\"$sub_sub_string\" undefined symbol type"
              tmp_error.columnNumber = column
              tmp_error.lineNumber = line
              push!(tmp_tokenized_error_array, tmp_error)
            else   # save tokens outside()
              tmp_token = TokenObject()
              tmp_token.tokenName = sub_sub_string
              tmp_token.tokenType = split(sub_sub_string, '_')[1]
              push!(tmp_token_array, tmp_token)
            end
          end
          push!(actor_token_array, tmp_token_array) # save tokens
        end
      end
    end
  end
end
