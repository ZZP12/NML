# set up data types
type sentenceObjectWithType
  originalSentence::String
  sentenceNo::Int64
  actionType::String
  function sentenceObjectWithType()
    this = new()
  end
end

type errorObject
  errorSentence::String
  lineNumber::Int
  columnNumber::Array{Int64,1}
  function errorObject()
    this = new()
  end
end

abstract GeneralToken
# token object
type TokenObject <: GeneralToken
  tokenName::String
  tokenType::String #user defined, does not contain '_'
  function TokenObject()
    this = new()
  end
end
# token object with coefficient
type coTokenObject <: GeneralToken
  tokenName::String
  tokenType::String
  tokenCoefficient::Float64
  function coTokenObject()
    this = new()
  end
end
# phosphorylation token object
type pTokenObject <: GeneralToken
  tokenName::String
  tokenType::String
  pSite::String
  function pTokenObject()
    this = new()
  end
end


# tokenized sentence type
abstract tokenizedSentence
type reactType <: tokenizedSentence
  actionType::String
  marker::Int
  symbolArray::Array{Array{Any,1},1}
  function reactType()
    this = new()
  end
end
type activateWithPostM <: tokenizedSentence
  actionType::String
  postMarker::Int64
  actorSymbol::Array{Array{TokenObject,1},1}
  mechanismMarker::Int64
  targetSymbol::TokenObject
  productSymbol::Array{coTokenObject,1}
  function activateWithPostM()
    this = new()
  end
end
type activateWithoutPostM <: tokenizedSentence
  actionType::String
  postMarker::Int64
  actorSymbol::Array{Array{TokenObject,1},1}
  mechanismMarker::Int64
  targetSymbol::Array{Array{TokenObject,1},1}
  function activateWithoutPostM()
    this = new()
  end
end
type translocateType <: tokenizedSentence
  actionType::String
  mechanismMarker::Int64
  targetSymbol::Array{Array{TokenObject,1},1}
  function translocateType()
    this = new()
  end
end
type uptakeSecreteType <: tokenizedSentence
  actionType::String
  mechanismMarker::Int64
  targetSymbol::Array{Array{TokenObject,1},1}
  transProtein::Array{Array{TokenObject,1},1}
  function uptakeSecreteType()
    this = new()
  end
end
type bindUnbindType <: tokenizedSentence
  actionType::String
  targetSymbol::Array{GeneralToken,1}
  productToken::TokenObject
  function bindUnbindType()
    this = new()
  end
end
type phosphorylateType <: tokenizedSentence
  actionType::String
  actorSymbol::Array{Array{TokenObject,1},1}
  targetSymbol::Array{Array{pTokenObject,1},1}
  function phosphorylateType()
    this = new()
  end
end
type catalyzeType <: tokenizedSentence
  actionType::String
  mechanismMarker::Int
  actorSymbol::Array{Array{TokenObject,1},1}
  targetSymbol::Array{coTokenObject,1}
  productSymbol::Array{coTokenObject,1}
  function catalyzeType()
    this = new()
  end
end
