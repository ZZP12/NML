# catalyze
function create_catalyze_AST(input_Sentence::sentenceObjectWithType, tokenized_sentence_array::Array{tokenizedSentence,1}, error_while_tokenizing_sentence::Array{errorObject,1})
  tmp_tokenized_error_array = Array{errorObject,1}() # as a counter: successfully tokenized or not
  mechanism_maker = 0 # default: 0 for irreversible, 1 for reversible
  actor_token_array = Array{Array{TokenObject,1},1}()  # catalysts
  target_token_array = Array{coTokenObject,1}()   # reactants
  product_token_array = Array{coTokenObject,1}()  # products
  mechanism_index = collect(search(input_Sentence.originalSentence, r" cataly(z|s)(e|es|ed|ing) the (reversible )?conversion of "))
  if isempty(mechanism_index) # no precise stings found --> grammar error
    tmp_error = errorObject()
    tmp_error.errorSentence = "grammar error --> no \"(reversible) conversion of\" found"
    tmp_error.columnNumber = [1, endof(input_Sentence.originalSentence)]
    tmp_error.lineNumber = input_Sentence.sentenceNo
    push!(tmp_tokenized_error_array, tmp_error)
  else # verbs string + reaction type found
    if !isempty(search(input_Sentence.originalSentence, " reversible ")) # reversible reaction
      mechanism_maker = 1
    end
    into_index = mechanism_index[end]-1 + collect(search(input_Sentence.originalSentence[mechanism_index[end]:end-1], " into "))
    if isempty(into_index) # no "into" found, grammar error
      tmp_error = errorObject()
      tmp_error.errorSentence = "grammar error --> no \" into \" found"
      tmp_error.columnNumber = [mechanism_index[end]+1, endof(input_Sentence.originalSentence)]
      tmp_error.lineNumber = input_Sentence.sentenceNo
      push!(tmp_tokenized_error_array, tmp_error)
    else  # has "into" --> correct in grammar
      actor_string = input_Sentence.originalSentence[1:mechanism_index[1]-1] # catalyst
      tokenize_and_or_logic_string_with_brackets(actor_string, [1, mechanism_index[1]-1], input_Sentence.sentenceNo, actor_token_array, tmp_tokenized_error_array)
      target_string = input_Sentence.originalSentence[mechanism_index[end]+1:into_index[1]-1] # reactants
      tokenize_symbols_with_stoichiometry_string(target_string, [mechanism_index[end]+1, into_index[1]-1], input_Sentence.sentenceNo, target_token_array, tmp_tokenized_error_array)
      product_string = input_Sentence.originalSentence[into_index[end]+1:end-1]
      tokenize_symbols_with_stoichiometry_string(product_string, [into_index[end]+1,endof(input_Sentence.originalSentence)-1], input_Sentence.sentenceNo, product_token_array, tmp_tokenized_error_array)
    end
  end
  if isempty(tmp_tokenized_error_array) # no error occured --> generating a type
    tokenized_sentence = catalyzeType()
    tokenized_sentence.actionType = "catalyze"
    tokenized_sentence.mechanismMarker = mechanism_maker
    tokenized_sentence.actorSymbol = actor_token_array
    tokenized_sentence.targetSymbol = target_token_array
    tokenized_sentence.productSymbol = product_token_array
    push!(tokenized_sentence_array, tokenized_sentence)
  else # return error
    append!(error_while_tokenizing_sentence, tmp_tokenized_error_array)
  end
end
