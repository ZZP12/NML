function create_splice_AST(input_Sentence::sentenceObjectWithType, tokenized_sentence_array::Array{tokenizedSentence,1}, error_while_tokenizing_sentence::Array{errorObject,1})
  # splice
  tmp_tokenized_error_array = Array{errorObject,1}() # as a counter: successfully tokenized or not
  target_token = TokenObject()
  product_token_array = Array{coTokenObject,1}()

  verb_index = collect(search(input_Sentence.originalSentence, r" splic(e|es|ed|ing) into "))
  target_string = input_Sentence.originalSentence[1:verb_index[1]-1]
  product_string = input_Sentence.originalSentence[verb_index[end]+1:end-1]

  tokenize_only_one_legal_symbol_string(target_string, [1, verb_index[1]-1], input_Sentence.sentenceNo, target_token, tmp_tokenized_error_array)
  tokenize_symbols_with_stoichiometry_string(product_string, [verb_index[end]+1,endof(input_Sentence.originalSentence)-1], input_Sentence.sentenceNo, product_token_array, tmp_tokenized_error_array)
  if isempty(tmp_tokenized_error_array) # no error occured --> generating a type
    tokenized_sentence = bindUnbindType()
    tokenized_sentence.actionType = "splice"
    tokenized_sentence.productToken = target_token
    tokenized_sentence.targetSymbol = product_token_array
    push!(tokenized_sentence_array, tokenized_sentence)
  else # return error
    append!(error_while_tokenizing_sentence, tmp_tokenized_error_array)
  end
end
