function create_uptake_AST(input_Sentence::sentenceObjectWithType, tokenized_sentence_array::Array{tokenizedSentence,1}, error_while_tokenizing_sentence::Array{errorObject,1})
  # uptake
  tmp_tokenized_error_array = Array{errorObject,1}() # as a counter: successfully tokenized or not
  target_token_array = Array{TokenObject,1}[]  # target
  mechanism_maker = 0
  verb_index = collect(search(input_Sentence.originalSentence, r"(t|T)he cell (uptak(e|es|ing)|uptook) "))
  mechanism_index = verb_index[end] + collect(search(input_Sentence.originalSentence[(verb_index[end]+1):end], r" through|thru "))
  if isempty(mechanism_index) # unknown mechanism type
    target_string = input_Sentence.originalSentence[verb_index[end]+1:end-1]
    tokenize_parentheses_and_logic_string(target_string, [verb_index[end]+1,endof(input_Sentence.originalSentence)-1], input_Sentence.sentenceNo, target_token_array, tmp_tokenized_error_array)
    if isempty(tmp_tokenized_error_array) # no error occured --> generating a type
      tokenized_sentence = uptakeSecreteType()
      tokenized_sentence.actionType = "uptake"
      tokenized_sentence.mechanismMarker = mechanism_maker
      tokenized_sentence.targetSymbol = target_token_array
      push!(tokenized_sentence_array, tokenized_sentence)
    else # return error
      append!(error_while_tokenizing_sentence, tmp_tokenized_error_array)
    end
  else # has transport proteins
    mechanism_maker = 1
    target_string = input_Sentence.originalSentence[verb_index[end]+1:mechanism_index[1]-1]
    tokenize_parentheses_and_logic_string(target_string, [verb_index[end]+1, mechanism_index[1]-1], input_Sentence.sentenceNo, target_token_array, tmp_tokenized_error_array)
    transProtein_string = input_Sentence.originalSentence[mechanism_index[end]+1: end-1]
    transProtein_token_array = Array{TokenObject,1}[]  # transProtein
    tokenize_and_or_logic_string(transProtein_string, [mechanism_index[end]+1, endof(input_Sentence.originalSentence)-1], input_Sentence.sentenceNo, transProtein_token_array, tmp_tokenized_error_array)
    if isempty(tmp_tokenized_error_array) # no error occured --> generating a type
      tokenized_sentence = uptakeSecreteType()
      tokenized_sentence.actionType = "uptake"
      tokenized_sentence.mechanismMarker = mechanism_maker
      tokenized_sentence.targetSymbol = target_token_array
      tokenized_sentence.transProtein = transProtein_token_array
      push!(tokenized_sentence_array, tokenized_sentence)
    else # return error
      append!(error_while_tokenizing_sentence, tmp_tokenized_error_array)
    end
  end
end

function create_secrete_AST(input_Sentence::sentenceObjectWithType, tokenized_sentence_array::Array{tokenizedSentence,1}, error_while_tokenizing_sentence::Array{errorObject,1})
  # uptake
  tmp_tokenized_error_array = Array{errorObject,1}() # as a counter: successfully tokenized or not
  target_token_array = Array{TokenObject,1}[]  # target
  mechanism_maker = 0
  verb_index = collect(search(input_Sentence.originalSentence, r"(t|T)he cell secret(e|es|ed|ing) "))
  mechanism_index = verb_index[end] + collect(search(input_Sentence.originalSentence[(verb_index[end]+1):end], r" through|thru "))
  if isempty(mechanism_index) # unknown mechanism type
    target_string = input_Sentence.originalSentence[verb_index[end]+1:end-1]
    tokenize_parentheses_and_logic_string(target_string, [verb_index[end]+1,endof(input_Sentence.originalSentence)-1], input_Sentence.sentenceNo, target_token_array, tmp_tokenized_error_array)
    if isempty(tmp_tokenized_error_array) # no error occured --> generating a type
      tokenized_sentence = uptakeSecreteType()
      tokenized_sentence.actionType = "secrete"
      tokenized_sentence.mechanismMarker = mechanism_maker
      tokenized_sentence.targetSymbol = target_token_array
      push!(tokenized_sentence_array, tokenized_sentence)
    else # return error
      append!(error_while_tokenizing_sentence, tmp_tokenized_error_array)
    end
  else # has transport proteins
    mechanism_maker = 1
    target_string = input_Sentence.originalSentence[verb_index[end]+1:mechanism_index[1]-1]
    tokenize_parentheses_and_logic_string(target_string, [verb_index[end]+1, mechanism_index[1]-1], input_Sentence.sentenceNo, target_token_array, tmp_tokenized_error_array)
    transProtein_string = input_Sentence.originalSentence[mechanism_index[end]+1: end-1]
    transProtein_token_array = Array{TokenObject,1}[]  # transProtein
    tokenize_and_or_logic_string(transProtein_string, [mechanism_index[end]+1, endof(input_Sentence.originalSentence)-1], input_Sentence.sentenceNo, transProtein_token_array, tmp_tokenized_error_array)
    if isempty(tmp_tokenized_error_array) # no error occured --> generating a type
      tokenized_sentence = uptakeSecreteType()
      tokenized_sentence.actionType = "secrete"
      tokenized_sentence.mechanismMarker = mechanism_maker
      tokenized_sentence.targetSymbol = target_token_array
      tokenized_sentence.transProtein = transProtein_token_array
      push!(tokenized_sentence_array, tokenized_sentence)
    else # return error
      append!(error_while_tokenizing_sentence, tmp_tokenized_error_array)
    end
  end
end
