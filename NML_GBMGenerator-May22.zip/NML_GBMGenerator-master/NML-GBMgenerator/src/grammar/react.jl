function create_react_AST(input_Sentence::sentenceObjectWithType, tokenized_sentence_array::Array{tokenizedSentence,1}, error_while_tokenizing_sentence::Array{errorObject,1})
  tmp_tokenized_error_array = Array{errorObject,1}() # as a counter: successfully tokenized or not
  verb_index = collect(search(input_Sentence.originalSentence, r"react(s|ed|ing)? into"))
  actor_string = input_Sentence.originalSentence[1:verb_index[1]-1]
  target_string = input_Sentence.originalSentence[verb_index[end]+1:end-1] # get rid of comma
  # check for "or"
  if isempty(search(actor_string*target_string, r" or |\|")) # legal in logic
    actor_token_array = Array{TokenObject,1}[]  # actor
    tokenize_parentheses_and_logic_string_with_brackets(actor_string, [1, verb_index[1]-1], input_Sentence.sentenceNo, actor_token_array, tmp_tokenized_error_array)
    target_token_array = Array{TokenObject,1}[]  # target
    tokenize_parentheses_and_logic_string_with_brackets(target_string, [verb_index[end]+1,endof(input_Sentence.originalSentence)-1], input_Sentence.sentenceNo, target_token_array, tmp_tokenized_error_array)
    # depend on results from tokenization, decide to create reactType or to output error
    if isempty(actor_token_array) && isempty(target_token_array)
      # both are []
      tmp_error = errorObject()
      tmp_error.errorSentence = "both symbol groups are empty"
      tmp_error.columnNumber = [1, verb_index[end]+1]
      tmp_error.lineNumber = input_Sentence.sentenceNo
      push!(tmp_tokenized_error_array, tmp_error)
      append!(error_while_tokenizing_sentence, tmp_tokenized_error_array)
    elseif (!isempty(actor_token_array)) && (!isempty(target_token_array))
      # both are non-[]
      tmp_error = errorObject()
      tmp_error.errorSentence = "\"React type\" does not suitable for two symbol groups that are both non-empty"
      tmp_error.columnNumber = [1, verb_index[end]+1]
      tmp_error.lineNumber = input_Sentence.sentenceNo
      push!(tmp_tokenized_error_array, tmp_error)
      append!(error_while_tokenizing_sentence, tmp_tokenized_error_array)
    elseif isempty(tmp_tokenized_error_array) && isempty(actor_token_array)
      # only actor is [], save target
      tokenized_sentence = reactType()
      tokenized_sentence.actionType = "react"
      tokenized_sentence.marker = 1
      # symbolArray = Array{Array{Any,1},1}()
      # push!(symbolArray, actor_token_array, target_token_array)
      tokenized_sentence.symbolArray = target_token_array
      push!(tokenized_sentence_array, tokenized_sentence)
    elseif isempty(tmp_tokenized_error_array) && isempty(target_token_array)
      # only target is [], save actor
      tokenized_sentence = reactType()
      tokenized_sentence.actionType = "react"
      tokenized_sentence.marker = 0
      # symbolArray = Array{Array{Any,1},1}()
      # push!(symbolArray, actor_token_array, target_token_array)
      tokenized_sentence.symbolArray = actor_token_array
      push!(tokenized_sentence_array, tokenized_sentence)
    else
      append!(error_while_tokenizing_sentence, tmp_tokenized_error_array)
    end
  else # contain "or"
    tmp_error = errorObject()
    tmp_error.errorSentence = "logic \"or\" is banned here"
    tmp_error.columnNumber = [1,verb_index[end]+1]
    tmp_error.lineNumber = input_Sentence.sentenceNo
    push!(error_while_tokenizing_sentence, tmp_error)
  end
end

function tokenize_parentheses_and_logic_string_with_brackets(actor_string::String, column::Array{Int,1}, line::Int, actor_token_array::Array{Array{TokenObject,1},1}, tmp_tokenized_error_array::Array{errorObject,1})
  # take in logically legal string, need to (empty?) (has parentheses? extract parentheses, extract tokens)
  if (split(actor_string)[1] == "[]") && length(split(actor_string))==1
    # is "[]"
  else # non empty "[]"
    actor_string = replace(actor_string, r",| and |&", " ")
    #process parentheses ()
    while(!isempty(search(actor_string, r"\(|\)")))  #process parentheses ()
      #process parentheses ()
      left_index = search(actor_string, '(')
      right_index = search(actor_string, ')')
      if (left_index == 0)||(right_index == 0)||(right_index < left_index) # unpaired ()
        # unpaired ()
        tmp_error = errorObject()
        tmp_error.errorSentence = "unpaired or mispaired ()"
        tmp_error.columnNumber = column
        tmp_error.lineNumber = line
        push!(tmp_tokenized_error_array, tmp_error)
        actor_string = replace(actor_string, r"\(|\)", " ") #break out of "while"
      else # paired, non-empty, but may contain '('
        # extract string inside parentheses, update actor_string
        sub_actor_string = actor_string[left_index+1:right_index-1]
        actor_string = replace(actor_string, actor_string[left_index:right_index], " ") # update actor_string
        if isempty(search(sub_actor_string, r"\(|\)"))
          # tokenizing symbols inside()
          sub_actor_string_array = split(sub_actor_string)
          tmp_token_array = TokenObject[]
          for sub_string in sub_actor_string_array
            if length(split(sub_string, '_')) < 2  #type undefined symbol
              tmp_error = errorObject()
              tmp_error.errorSentence = "type undefined symbol found inside ()"
              tmp_error.columnNumber = column
              tmp_error.lineNumber = line
              push!(tmp_tokenized_error_array, tmp_error)
            else  # found a symbol
              tmp_token = TokenObject()
              tmp_token.tokenName = sub_string
              tmp_token.tokenType = split(sub_string, '_')[1]
              push!(tmp_token_array, tmp_token)
            end
          end
          push!(actor_token_array, tmp_token_array) # save tokens inside (), may only contain incomplete information
        else  # more than one level of ()
          tmp_error = errorObject()
          tmp_error.errorSentence = "only one level of \"()\" is allowed"
          tmp_error.columnNumber = column
          tmp_error.lineNumber = line
          push!(tmp_tokenized_error_array, tmp_error)
        end
      end
    end
    # now, processing symbols outside parentheses
    actor_string_array = split(actor_string)
    for sub_string in actor_string_array
      if (length(split(sub_string, '_')) < 2)  #type undefined symbol
        tmp_error = errorObject()
        tmp_error.errorSentence = "no fully defined symbol found outside ()"
        tmp_error.columnNumber = column
        tmp_error.lineNumber = line
        push!(tmp_tokenized_error_array, tmp_error)
      else   # save tokens outside(), may only contain incomplete information
        tmp_token_array = TokenObject[]
        tmp_token = TokenObject()
        tmp_token.tokenName = sub_string
        tmp_token.tokenType = split(sub_string, '_')[1]
        push!(tmp_token_array, tmp_token)
        push!(actor_token_array, tmp_token_array)
      end
    end
  end
end
