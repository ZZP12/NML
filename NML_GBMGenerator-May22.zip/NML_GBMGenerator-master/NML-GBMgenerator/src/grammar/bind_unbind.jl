# bind-unbind
function create_bind_AST(input_Sentence::sentenceObjectWithType, tokenized_sentence_array::Array{tokenizedSentence,1}, error_while_tokenizing_sentence::Array{errorObject,1})
  tmp_tokenized_error_array = Array{errorObject,1}() # as a counter: successfully tokenized or not
  target_token_array = Array{TokenObject,1}()  # target
  verb_index = collect(search(input_Sentence.originalSentence, r" (bind(s|ing)?|bound|associat(e|es|ed|ing)|complex(es|ed|ing)?)( |;)"))
  if (verb_index[end] < length(input_Sentence.originalSentence)) # if end with ";", "verb_index[end]+1" can throw error.
    mechanism_index = verb_index[end] + collect(search(input_Sentence.originalSentence[(verb_index[end]+1):end], "to form "))
    if isempty(mechanism_index) # unclear mechanism or typos
      tmp_error = errorObject()
      tmp_error.errorSentence = "unclear mechanism or typos found"
      tmp_error.columnNumber = [verb_index[end], endof(input_Sentence.originalSentence)]
      tmp_error.lineNumber = input_Sentence.sentenceNo
      push!(tmp_tokenized_error_array, tmp_error)
      append!(error_while_tokenizing_sentence, tmp_tokenized_error_array)  #Don’t forget to return error!!!
    else  # has product
      target_string = input_Sentence.originalSentence[1:verb_index[1]-1]
      product_string = input_Sentence.originalSentence[mechanism_index[end]+1:end-1]
      product_token = TokenObject()
      tokenize_and_only_logic_string(target_string, [1,verb_index[1]-1], input_Sentence.sentenceNo, target_token_array, tmp_tokenized_error_array)
      tokenize_only_one_legal_symbol_string(product_string, [mechanism_index[end]+1, endof(input_Sentence.originalSentence)-1], input_Sentence.sentenceNo, product_token, tmp_tokenized_error_array)
      if isempty(tmp_tokenized_error_array) # no error occured --> generating a type
        tokenized_sentence = bindUnbindType()
        tokenized_sentence.actionType = "bind"
        tokenized_sentence.targetSymbol = target_token_array
        tokenized_sentence.productToken = product_token
        push!(tokenized_sentence_array, tokenized_sentence)
      else # return error
        append!(error_while_tokenizing_sentence, tmp_tokenized_error_array)
      end
    end
  else # does not have product
    target_string = input_Sentence.originalSentence[1:verb_index[1]-1]
    tokenize_and_only_logic_string(target_string, [1,verb_index[1]-1], input_Sentence.sentenceNo, target_token_array, tmp_tokenized_error_array)
    if isempty(tmp_tokenized_error_array) # no error occured --> generating a type
      tokenized_sentence = bindUnbindType()
      tokenized_sentence.actionType = "bind"
      tokenized_sentence.targetSymbol = target_token_array
      push!(tokenized_sentence_array, tokenized_sentence)
    else # return error
      append!(error_while_tokenizing_sentence, tmp_tokenized_error_array)
    end
  end
end

function create_unbind_AST(input_Sentence::sentenceObjectWithType, tokenized_sentence_array::Array{tokenizedSentence,1}, error_while_tokenizing_sentence::Array{errorObject,1})
  tmp_tokenized_error_array = Array{errorObject,1}() # as a counter: successfully tokenized or not
  target_token_array = Array{TokenObject,1}()  # target
  # unbind type must have verb_index (this was guaranteed when searched for type)
  verb_index = collect(search(input_Sentence.originalSentence, r" (unbind(s|ing)?|unbound|disassociat(e|es|ed|ing));"))
  target_string = input_Sentence.originalSentence[1:verb_index[1]-1]
  tokenize_and_only_logic_complex_string(target_string, [1,verb_index[1]-1], input_Sentence.sentenceNo, target_token_array, tmp_tokenized_error_array)
  if !isempty(target_token_array) #for unbind, each target_token should have at least one ":" as an indication of product components
    for sub_token in target_token_array # check each token
      sub_token_arr = split(sub_token.tokenName, ':')
      if length(sub_token_arr) < 2 # no ":" --> error
        tmp_error = errorObject()
        tmp_error.errorSentence = "no \':\' found"
        tmp_error.columnNumber = [1, verb_index[1]-1]
        tmp_error.lineNumber = input_Sentence.sentenceNo
        push!(tmp_tokenized_error_array, tmp_error)
      end
    end
  end
  if isempty(tmp_tokenized_error_array)  # no error occured --> generating a type
    tokenized_sentence = bindUnbindType()
    tokenized_sentence.actionType = "unbind"
    tokenized_sentence.targetSymbol = target_token_array
    push!(tokenized_sentence_array, tokenized_sentence)
  else # return error
    append!(error_while_tokenizing_sentence, tmp_tokenized_error_array)
  end
end

function tokenize_and_only_logic_string(target_string::String, column::Array{Int,1}, line::Int, target_token_array::Array{TokenObject,1}, tmp_tokenized_error_array::Array{errorObject,1})
  if length(split(target_string)) == 0   # empty symbol
    tmp_error = errorObject()
    tmp_error.errorSentence = "empty symbol"
    tmp_error.columnNumber = column
    tmp_error.lineNumber = line
    push!(tmp_tokenized_error_array, tmp_error)
  else # non-empty
    if !isempty(search(target_string, r" or |\||\(|\)")) # has logic "or" or "()"
      tmp_error = errorObject()
      tmp_error.errorSentence = "both logic \"()\" and \"or\" are not allowed"
      tmp_error.columnNumber = column
      tmp_error.lineNumber = line
      push!(tmp_tokenized_error_array, tmp_error)
    else # only has logic "&"
      target_string = replace(target_string, r" and |&|,", " ")
      target_string_array = split(target_string)   # target tokens
      for sub_string in target_string_array
        if (length(split(sub_string, '_')) < 2)  # type undefined symbol (should at least be 2, can have suffix)
          tmp_error = errorObject()
          tmp_error.errorSentence = "\"$sub_string\" is an imcomplete symbol"
          tmp_error.columnNumber = column
          tmp_error.lineNumber = line
          push!(tmp_tokenized_error_array, tmp_error)
        else   #has type
          tmp_token = TokenObject()
          tmp_token.tokenName = sub_string
          tmp_token.tokenType = split(sub_string, '_')[1]
          push!(target_token_array, tmp_token)
        end
      end
    end
  end
end


function tokenize_and_only_logic_complex_string(target_string::String, column::Array{Int,1}, line::Int, target_token_array::Array{TokenObject,1}, tmp_tokenized_error_array::Array{errorObject,1})
  # m_A:k_D:a_C_D, m_A:k_D, k_D:a_C_D
  if length(split(target_string)) == 0   # empty symbol
    tmp_error = errorObject()
    tmp_error.errorSentence = "empty symbol"
    tmp_error.columnNumber = column
    tmp_error.lineNumber = line
    push!(tmp_tokenized_error_array, tmp_error)
  else # non-empty
    if !isempty(search(target_string, r" or |\||\(|\)")) # has logic "or" or "()"
      tmp_error = errorObject()
      tmp_error.errorSentence = "both logic \"()\" and \"or\" are not allowed"
      tmp_error.columnNumber = column
      tmp_error.lineNumber = line
      push!(tmp_tokenized_error_array, tmp_error)
    else # only has logic "&"
      target_string = replace(target_string, r" and |&|,", " ")
      target_string_array = split(target_string)   # target tokens
      for sub_string in target_string_array  # check each token for delimiter colon & type indicator '_'
        tmp_tmp_tokenized_error = errorObject[] # indicating the correctness of each token
        sub_string_arr = split(sub_string, ':')
        if length(sub_string_arr) < 2  # no ':' --> error
          tmp_error = errorObject()
          tmp_error.errorSentence = "no \':\' found in \"$sub_string\""
          tmp_error.columnNumber = column
          tmp_error.lineNumber = line
          push!(tmp_tmp_tokenized_error, tmp_error)
        else   # has ':', check for '_'
          for sub_sub_string in sub_string_arr
            if (length(split(sub_sub_string, '_')) < 2)  #type undefined symbol (should at least be 2, can have suffix)
              tmp_error = errorObject()
              tmp_error.errorSentence = "\"$sub_sub_string\" is an imcomplete symbol"
              tmp_error.columnNumber = column
              tmp_error.lineNumber = line
              push!(tmp_tmp_tokenized_error, tmp_error)
            end
          end
        end
        if isempty(tmp_tmp_tokenized_error) # no error --> generate a token
          tmp_token = TokenObject()
          tmp_token.tokenName = sub_string
          tmp_token.tokenType = "complex"
          push!(target_token_array, tmp_token)
        else  # has error
          append!(tmp_tokenized_error_array, tmp_tmp_tokenized_error)
        end
      end
    end
  end
end
