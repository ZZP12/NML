function create_activate_AST(input_Sentence::sentenceObjectWithType, tokenized_sentence_array::Array{tokenizedSentence,1}, error_while_tokenizing_sentence::Array{errorObject,1})
  #activate
  tmp_tokenized_error_array = Array{errorObject,1}() # as a counter: successfully tokenized or not
  post_marker = 0
  mechanism_maker = 0
  verb_index = collect(search(input_Sentence.originalSentence, r" (upregulat|promot|activat)(e|es|ed|ing) "))
  mechanism_index = verb_index[end] + collect(search(input_Sentence.originalSentence[(verb_index[end]+1):end], r"the (expression|transcription|translation) of"))

  if isempty(mechanism_index) # unknown mechanism type
    # no precise matching of "the expression|transcription|tranlation of"
    # maybe some typo in "the expression|transcription|tranlation of"
    # generate error but still treat this sentence as w/o mechanism.
    typoSearchRange_index =verb_index[end] + collect(search(input_Sentence.originalSentence[verb_index[end]+1:end], r"_|;"))[1]
    if length(input_Sentence.originalSentence[(verb_index[end]+1):(typoSearchRange_index)]) > 12  # may be typos
      tmp_error = errorObject()
      tmp_error.errorSentence = "may be a \"the expression/transcription/tranlation of\" but has typos"
      tmp_error.columnNumber = [verb_index[end]+1]
      tmp_error.lineNumber = input_Sentence.sentenceNo
      push!(error_while_tokenizing_sentence, tmp_error)
    end
    actor_token_array = Array{TokenObject,1}[]  # actor
    target_token_array = Array{TokenObject,1}[]  # target
    actor_string = input_Sentence.originalSentence[1:verb_index[1]-1]
    target_string = input_Sentence.originalSentence[verb_index[end]+1:end-1]
    tokenize_and_or_logic_string(actor_string, [1, verb_index[1]-1], input_Sentence.sentenceNo, actor_token_array, tmp_tokenized_error_array)
    tokenize_parentheses_and_logic_string(target_string, [verb_index[end]+1,endof(input_Sentence.originalSentence)-1], input_Sentence.sentenceNo, target_token_array, tmp_tokenized_error_array)
    if isempty(tmp_tokenized_error_array) # no error occured --> generating a type
      tokenized_sentence = activateWithoutPostM()
      tokenized_sentence.actionType = "activate"
      tokenized_sentence.postMarker = post_marker
      tokenized_sentence.actorSymbol = actor_token_array
      tokenized_sentence.mechanismMarker = mechanism_maker
      tokenized_sentence.targetSymbol = target_token_array
      push!(tokenized_sentence_array, tokenized_sentence)
    else # return error
      append!(error_while_tokenizing_sentence, tmp_tokenized_error_array)
    end
  else # has mechanism: expression/ transcription/ translation
    # find the mechanism type
    if !isempty(search(input_Sentence.originalSentence[(mechanism_index[1]):(mechanism_index[end])], "transcription"))
      mechanism_maker = 1
    elseif !isempty(search(input_Sentence.originalSentence[(mechanism_index[1]):(mechanism_index[end])], "tranlation"))
      mechanism_maker = 2
    else
      mechanism_maker = 3
    end
    into_index = mechanism_index[end] + collect(search(input_Sentence.originalSentence[mechanism_index[end]+1:end], " into "))
    if isempty(into_index) # has a defined mechanism but not a post-modification)
      # symbol tokenization is the same as unknown mechanism
      actor_token_array = Array{TokenObject,1}[]  # actor
      target_token_array = Array{TokenObject,1}[]  # target
      actor_string = input_Sentence.originalSentence[1:verb_index[1]-1]
      target_string = input_Sentence.originalSentence[(mechanism_index[end]+1):(end-1)]
      tokenize_and_or_logic_string(actor_string, [1, verb_index[1]-1], input_Sentence.sentenceNo, actor_token_array, tmp_tokenized_error_array)
      tokenize_parentheses_and_logic_string(target_string, [mechanism_index[end]+1,endof(input_Sentence.originalSentence)-1], input_Sentence.sentenceNo, target_token_array, tmp_tokenized_error_array)
      if isempty(tmp_tokenized_error_array) # no error occured --> generating a type
        tokenized_sentence = activateWithoutPostM()
        tokenized_sentence.actionType = "activate"
        tokenized_sentence.postMarker = post_marker
        tokenized_sentence.actorSymbol = actor_token_array
        tokenized_sentence.mechanismMarker = mechanism_maker
        tokenized_sentence.targetSymbol = target_token_array
        push!(tokenized_sentence_array, tokenized_sentence)
      else # return error
        append!(error_while_tokenizing_sentence, tmp_tokenized_error_array)
      end
    else  # post-modification
      post_marker = 1
      actor_token_array = Array{TokenObject,1}[]  # actor
      actor_string = input_Sentence.originalSentence[1:verb_index[1]-1]
      tokenize_and_or_logic_string(actor_string, [1, verb_index[1]-1], input_Sentence.sentenceNo, actor_token_array, tmp_tokenized_error_array)
      target_string = input_Sentence.originalSentence[mechanism_index[end]+1:into_index[1]-1]
      target_token = TokenObject()
      tokenize_only_one_legal_symbol_string(target_string, [mechanism_index[end]+1, into_index[1]], input_Sentence.sentenceNo, target_token, tmp_tokenized_error_array)
      product_token_array = Array{coTokenObject,1}()
      product_string = input_Sentence.originalSentence[into_index[end]+1:end-1]
      tokenize_symbols_with_stoichiometry_string(product_string, [into_index[end]+1,endof(input_Sentence.originalSentence)-1], input_Sentence.sentenceNo, product_token_array, tmp_tokenized_error_array)
      if isempty(tmp_tokenized_error_array) # no error occured --> generating a type
        tokenized_sentence = activateWithPostM()
        tokenized_sentence.actionType = "activate"
        tokenized_sentence.postMarker = post_marker
        tokenized_sentence.actorSymbol = actor_token_array
        tokenized_sentence.mechanismMarker = mechanism_maker
        tokenized_sentence.targetSymbol = target_token
        tokenized_sentence.productSymbol = product_token_array
        push!(tokenized_sentence_array, tokenized_sentence)
      else # return error
        append!(error_while_tokenizing_sentence, tmp_tokenized_error_array)
      end
    end
  end
end
