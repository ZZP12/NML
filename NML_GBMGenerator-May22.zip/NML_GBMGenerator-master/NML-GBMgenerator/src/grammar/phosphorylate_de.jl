# phosphorylate & dephosphorylate
function create_phosphorylate_AST(input_Sentence::sentenceObjectWithType, tokenized_sentence_array::Array{tokenizedSentence,1}, error_while_tokenizing_sentence::Array{errorObject,1})
  #activate
  tmp_tokenized_error_array = Array{errorObject,1}() # as a counter: successfully tokenized or not
  actor_token_array = Array{TokenObject,1}[]  # actor
  target_token_array = Array{pTokenObject,1}[]  # target
  verb_index = collect(search(input_Sentence.originalSentence, r" phosphorylat(e|es|ed|ing) "))
  mechanism_index = verb_index[end] + collect(search(input_Sentence.originalSentence[(verb_index[end]+1):end], r" at sites? "))
  if isempty(mechanism_index)  # w/o sites
    actor_string = input_Sentence.originalSentence[1:verb_index[1]-1]
    target_string = input_Sentence.originalSentence[verb_index[end]:end-1]
    site_string = "EMPTY"
    tokenize_and_or_logic_string_with_brackets(actor_string, [1,verb_index[1]-1], input_Sentence.sentenceNo, actor_token_array, tmp_tokenized_error_array)  # only one brackets is allowed
    tokenize_parentheses_and_logic_string_with_sites(target_string, [verb_index[end],endof(input_Sentence.originalSentence)-1], site_string, [0], input_Sentence.sentenceNo, target_token_array, tmp_tokenized_error_array)
    if isempty(tmp_tokenized_error_array) # no error occured --> generating a type
      tokenized_sentence = phosphorylateType()
      tokenized_sentence.actionType = "phosphorylate"
      tokenized_sentence.actorSymbol = actor_token_array
      tokenized_sentence.targetSymbol = target_token_array
      push!(tokenized_sentence_array, tokenized_sentence)
    else # return error
      append!(error_while_tokenizing_sentence, tmp_tokenized_error_array)
    end
  else # has sites
    actor_string = input_Sentence.originalSentence[1:verb_index[1]]
    target_string = input_Sentence.originalSentence[(verb_index[end]):(mechanism_index[1])]
    site_string = input_Sentence.originalSentence[(mechanism_index[end]):end-1]
    tokenize_and_or_logic_string_with_brackets(actor_string, [1, verb_index[1]-1], input_Sentence.sentenceNo, actor_token_array, tmp_tokenized_error_array)  # only one brackets is allowed
    tokenize_parentheses_and_logic_string_with_sites(target_string, [verb_index[end], mechanism_index[1]], site_string, [mechanism_index[end],endof(input_Sentence.originalSentence)-1], input_Sentence.sentenceNo, target_token_array, tmp_tokenized_error_array)
    if isempty(tmp_tokenized_error_array) # no error occured --> generating a type
      tokenized_sentence = phosphorylateType()
      tokenized_sentence.actionType = "phosphorylate"
      tokenized_sentence.actorSymbol = actor_token_array
      tokenized_sentence.targetSymbol = target_token_array
      push!(tokenized_sentence_array, tokenized_sentence)
    else # return error
      append!(error_while_tokenizing_sentence, tmp_tokenized_error_array)
    end
  end
end

function create_dephosphorylate_AST(input_Sentence::sentenceObjectWithType, tokenized_sentence_array::Array{tokenizedSentence,1}, error_while_tokenizing_sentence::Array{errorObject,1})
  #activate
  tmp_tokenized_error_array = Array{errorObject,1}() # as a counter: successfully tokenized or not
  actor_token_array = Array{TokenObject,1}[]  # actor
  target_token_array = Array{pTokenObject,1}[]  # target
  verb_index = collect(search(input_Sentence.originalSentence, r" dephosphorylat(e|es|ed|ing) "))
  mechanism_index = verb_index[end] + collect(search(input_Sentence.originalSentence[(verb_index[end]+1):end], r" at sites? "))
  if isempty(mechanism_index)  # w/o sites
    actor_string = input_Sentence.originalSentence[1:verb_index[1]-1]
    target_string = input_Sentence.originalSentence[verb_index[end]:end-1]
    site_string = "EMPTY"
    tokenize_and_or_logic_string_with_brackets(actor_string, [1,verb_index[1]-1], input_Sentence.sentenceNo, actor_token_array, tmp_tokenized_error_array)  # only one brackets is allowed
    tokenize_parentheses_and_logic_string_with_sites(target_string, [verb_index[end],endof(input_Sentence.originalSentence)-1], site_string, [0], input_Sentence.sentenceNo, target_token_array, tmp_tokenized_error_array)
    if isempty(tmp_tokenized_error_array) # no error occured --> generating a type
      tokenized_sentence = phosphorylateType()
      tokenized_sentence.actionType = "dephosphorylate"
      tokenized_sentence.actorSymbol = actor_token_array
      tokenized_sentence.targetSymbol = target_token_array
      push!(tokenized_sentence_array, tokenized_sentence)
    else # return error
      append!(error_while_tokenizing_sentence, tmp_tokenized_error_array)
    end
  else # has sites
    actor_string = input_Sentence.originalSentence[1:verb_index[1]]
    target_string = input_Sentence.originalSentence[(verb_index[end]):(mechanism_index[1])]
    site_string = input_Sentence.originalSentence[(mechanism_index[end]):end-1]
    tokenize_and_or_logic_string_with_brackets(actor_string, [1, verb_index[1]-1], input_Sentence.sentenceNo, actor_token_array, tmp_tokenized_error_array)  # only one brackets is allowed
    tokenize_parentheses_and_logic_string_with_sites(target_string, [verb_index[end], mechanism_index[1]], site_string, [mechanism_index[end],endof(input_Sentence.originalSentence)-1], input_Sentence.sentenceNo, target_token_array, tmp_tokenized_error_array)
    if isempty(tmp_tokenized_error_array) # no error occured --> generating a type
      tokenized_sentence = phosphorylateType()
      tokenized_sentence.actionType = "dephosphorylate"
      tokenized_sentence.actorSymbol = actor_token_array
      tokenized_sentence.targetSymbol = target_token_array
      push!(tokenized_sentence_array, tokenized_sentence)
    else # return error
      append!(error_while_tokenizing_sentence, tmp_tokenized_error_array)
    end
  end
end


function tokenize_parentheses_and_logic_string_with_sites(target_string::String, target_column::Array{Int,1}, site_string::String, site_column::Array{Int,1}, line::Int, target_token_array::Array{Array{pTokenObject,1},1}, tmp_tokenized_error_array::Array{errorObject,1})
  # tokenizing target_string and site_string separately, then match targets and sites
  # take in string, using rule "() > and, but not or"
  # processing target_string
  if !isempty(search(target_string, r" or |\|")) # has "or"
    tmp_error = errorObject()
    tmp_error.errorSentence = "logic \"or\" are not allowed"
    tmp_error.columnNumber = target_column
    tmp_error.lineNumber = line
    push!(tmp_tokenized_error_array, tmp_error)
  else # does not have "or"
    if  length(split(target_string)) == 0 # empty
      tmp_error = errorObject()
      tmp_error.errorSentence = "empty symbol"
      tmp_error.columnNumber = target_column
      tmp_error.lineNumber = line
      push!(tmp_tokenized_error_array, tmp_error)
    else # non empty
      target_string = replace(target_string, r",| and |&", " ")
      #process parentheses ()
      while(!isempty(search(target_string, r"\(|\)")))  #process parentheses ()
        left_index = search(target_string, '(')
        right_index = search(target_string, ')')
        if (left_index == 0)||(right_index == 0)||(right_index < left_index) # unpaired ()
          # unpaired ()
          tmp_error = errorObject()
          tmp_error.errorSentence = "unpaired or mispaired ()"
          tmp_error.columnNumber = target_column
          tmp_error.lineNumber = line
          push!(tmp_tokenized_error_array, tmp_error)
          target_string = replace(target_string, r"\(|\)", " ") #break out of "while"
        else # paired, non-empty, but may contain '('
          sub_target_string = target_string[left_index+1:right_index-1]  # extract string inside parentheses
          target_string = replace(target_string, target_string[left_index:right_index], " ") # update target_string
          if isempty(search(sub_target_string, r"\(|\)"))  # tokenizing symbols inside()
            # tokenizing symbols inside()
            sub_target_string_array = split(sub_target_string)
            tmp_token_array = pTokenObject[]
            for sub_string in sub_target_string_array
              if length(split(sub_string, '_')) < 2  #type undefined symbol
                tmp_error = errorObject()
                tmp_error.errorSentence = "\"$sub_string\" is an imcomplete symbol"
                tmp_error.columnNumber = target_column
                tmp_error.lineNumber = line
                push!(tmp_tokenized_error_array, tmp_error)
              else  # found a symbol
                tmp_token = pTokenObject()
                tmp_token.tokenName = sub_string
                tmp_token.tokenType = split(sub_string, '_')[1]
                push!(tmp_token_array, tmp_token)
              end
            end
            push!(target_token_array, tmp_token_array) # save tokens inside (), may be empty or only contain incomplete information
          else  # more than one level of ()
            tmp_error = errorObject()
            tmp_error.errorSentence = "only one level of \"()\" is allowed"
            tmp_error.columnNumber = target_column
            tmp_error.lineNumber = line
            push!(tmp_tokenized_error_array, tmp_error)
          end
        end
      end
      # now, processing symbols outside parentheses
      target_string_array = split(target_string)
      for sub_string in target_string_array
        if (length(split(sub_string, '_')) < 2)  #type undefined symbol
          tmp_error = errorObject()
          tmp_error.errorSentence = "\"$sub_string\" is an imcomplete symbol"
          tmp_error.columnNumber = target_column
          tmp_error.lineNumber = line
          push!(tmp_tokenized_error_array, tmp_error)
        else   # found a symbol
          tmp_token_array = pTokenObject[]
          tmp_token = pTokenObject()
          tmp_token.tokenName = sub_string
          tmp_token.tokenType = split(sub_string, '_')[1]
          push!(tmp_token_array, tmp_token)
          push!(target_token_array, tmp_token_array)
        end
      end
    end
  end
  # processing site_string
  if site_string == "EMPTY" # no sites
    # no sites
  else  # have sites
    site_token_array = Array{Array{String,1},1}()
    if !isempty(search(site_string, r" or |\|")) # has "or"
      tmp_error = errorObject()
      tmp_error.errorSentence = "logic \"or\" are not allowed"
      tmp_error.columnNumber = site_column
      tmp_error.lineNumber = line
      push!(tmp_tokenized_error_array, tmp_error)
    else # does not have "or"
      if  length(split(site_string)) == 0 # empty
        tmp_error = errorObject()
        tmp_error.errorSentence = "empty symbol"
        tmp_error.columnNumber = site_column
        tmp_error.lineNumber = line
        push!(tmp_tokenized_error_array, tmp_error)
      else # non empty
        site_string = replace(site_string, r",| and |&", " ")
        #process parentheses ()
        while(!isempty(search(site_string, r"\(|\)")))  #process parentheses ()
          left_index = search(site_string, '(')
          right_index = search(site_string, ')')
          if (left_index == 0)||(right_index == 0)||(right_index < left_index) # unpaired ()
            # unpaired ()
            tmp_error = errorObject()
            tmp_error.errorSentence = "unpaired or mispaired ()"
            tmp_error.columnNumber = site_column
            tmp_error.lineNumber = line
            push!(tmp_tokenized_error_array, tmp_error)
            site_string = replace(site_string, r"\(|\)", " ") #break out of "while"
          else # paired, non-empty, but may contain '('
            sub_site_string = site_string[left_index+1:right_index-1]  # extract string inside parentheses
            site_string = replace(site_string, site_string[left_index:right_index], " ") # update site_string
            if isempty(search(sub_site_string, r"\(|\)"))  # tokenizing symbols inside()
              # tokenizing symbols inside()
              sub_site_string_array = split(sub_site_string)
              tmp_site_array = Array{String,1}()
              for sub_string in sub_site_string_array
                  push!(tmp_site_array, sub_string)
              end
              push!(site_token_array, tmp_site_array) # save tokens inside (), may be empty or only contain incomplete information
            else  # more than one level of ()
              tmp_error = errorObject()
              tmp_error.errorSentence = "only one level of \"()\" is allowed"
              tmp_error.columnNumber = site_column
              tmp_error.lineNumber = line
              push!(tmp_tokenized_error_array, tmp_error)
            end
          end
        end
        # now, processing symbols outside parentheses
        site_string_array = split(site_string)
        for sub_string in site_string_array
          tmp_site_array = Array{String,1}()
          push!(tmp_site_array, sub_string)
          push!(site_token_array, tmp_site_array)
        end
      end
    end
    # matching sites with targets
    if (length(target_token_array) != length(site_token_array)) # length is not the same
      tmp_error = errorObject()
      tmp_error.errorSentence = "numbers of targets and sites are not matched "
      tmp_error.columnNumber = append!(target_column, site_column)
      tmp_error.lineNumber = line
      push!(tmp_tokenized_error_array, tmp_error)
    else  # total size is the same, check each sub_array
      for (i, sub_token) in enumerate(target_token_array) # check each sub_array
        if (length(target_token_array[i]) != length(site_token_array[i]))  # length of this component is not the same
          tmp_error = errorObject()
          tmp_error.errorSentence = "the $i target and site are not matched "
          tmp_error.columnNumber = append!(target_column, site_column)
          tmp_error.lineNumber = line
          push!(tmp_tokenized_error_array, tmp_error)
        else  # matched, transfer Sites
          for (j, sub_t_t) in enumerate(target_token_array[i])
            sub_s = site_token_array[i]
            sub_t_t.pSite = sub_s[j]
          end
        end
      end
    end
  end
end
