# translocate into/out of
function create_translocate_AST(input_Sentence::sentenceObjectWithType, tokenized_sentence_array::Array{tokenizedSentence,1}, error_while_tokenizing_sentence::Array{errorObject,1})
  # translocate
  tmp_tokenized_error_array = Array{errorObject,1}() # as a counter: successfully tokenized or not
  mechanism_maker = 1 # 1 for into
  target_token_array = Array{TokenObject,1}[]  # target
  verb_index = collect(search(input_Sentence.originalSentence, r" translocat(e|es|ed|ing) (into|out of) "))
  if !isempty(search(input_Sentence.originalSentence, r" translocat(e|es|ed|ing) out of")) # 2 for "out of"
    mechanism_maker = 2 # 2 for "out of"
  end
  target_string = input_Sentence.originalSentence[1:verb_index[1]-1]
  tokenize_parentheses_and_logic_string(target_string, [1,verb_index[1]-1], input_Sentence.sentenceNo, target_token_array, tmp_tokenized_error_array)
  if isempty(tmp_tokenized_error_array) # no error occured --> generating a type
    tokenized_sentence = translocateType()
    tokenized_sentence.actionType = "translocate"
    tokenized_sentence.mechanismMarker = mechanism_maker
    tokenized_sentence.targetSymbol = target_token_array
    push!(tokenized_sentence_array, tokenized_sentence)
  else # return error
    append!(error_while_tokenizing_sentence, tmp_tokenized_error_array)
  end
end
