# test
include("src/types.jl")

cotokentest = coTokenObject()
cotokentest.tokenName = "inheritance"
cotokentest.tokenCoefficient = 1
println(cotokentest)
