#=
using ArgParse

function parse_commandline()
  # zzp define a command-line interface
  settings_object = ArgParseSettings()
  @add_arg_table settings_object begin
    "-o"
      help = "Directory where the Julia model files will be written."
      arg_type = AbstractString
      default = "."

    "-m"
      help = "Path to the model file written in the NML format."
      arg_type = AbstractString
      required = true

    "-s"
      help = "Host type: HL-60 or PCa?"
      arg_type = Symbol
      default = :Pca
  end
  return parse_args(settings_object)
end

function main()
  parsed_args = parse_commandline()
  =#
  # Load the statement_vector -

include("./src/types.jl")
include("./src/parser.jl")
include("./src/grammar_utility.jl")
include("./src/grammar/react.jl")
include("./src/grammar/activate.jl")
include("./src/grammar/inhibit.jl")
include("./src/grammar/translocate.jl")
include("./src/grammar/uptake_secrete.jl")
include("./src/grammar/bind_unbind.jl")
include("./src/grammar/splice.jl")
include("./src/grammar/phosphorylate_de.jl")
include("./src/grammar/catalyze.jl")

path_to_model_file = "./test/pseudoNML.net"
(input_Sentence_Array, unusual_chars_error_messenges) = load_model_statements(path_to_model_file)


invalid_sentence_counter = find_sentence_type_of_all_sentences(input_Sentence_Array, unusual_chars_error_messenges)

next_step = false # indicator of process
if invalid_sentence_counter == 0
  # now, all sentences have types, start to find symbol conversion dictionary
  reservedWords = Set{String}(["TAGgene", "TAGmRNA", "TAGprotein", "TAGmetabolite", "_PHOS", "_UBI", "_ACE", "_EXTRA", "_NUC","_CYT"])
  (symbol_conversion_dict, symbol_conv_grammar_error) = set_up_symbol_conversion_dict(input_Sentence_Array, reservedWords)
  if isempty(symbol_conv_grammar_error)
    next_step = true
    println("\n======symbol conversion list===========")
    for (key_user, value_sys) in symbol_conversion_dict
      println(key_user, " ==> ", value_sys)
    end
  else
    println("\n====conversion grammar error===========")
    for error in symbol_conv_grammar_error
      println("In line $(error.lineNumber) "*error.errorSentence*" at $(error.columnNumber)")
    end
  end
end

if (next_step)
  next_step = false
  # after successfully created the symbol conversion dictionary, start to tokenize every sentence
  println("\n====begin tokenization............")
  (tokenized_sentence_array, error_while_tokenizing_sentence) = tokenize_all_sentence(input_Sentence_Array)
  if isempty(error_while_tokenizing_sentence)
    next_step = true
    println("\n=============AST================")
    for sentence in tokenized_sentence_array
      println()
      println(sentence)
    end
  else
    println("\n====errors while tokenizing sentence.................")
    for error in error_while_tokenizing_sentence
      println("In line $(error.lineNumber) at $(error.columnNumber) \""*error.errorSentence*"\"")
    end
  end
end
