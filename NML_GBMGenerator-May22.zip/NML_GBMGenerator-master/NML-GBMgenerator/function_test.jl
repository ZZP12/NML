# test
include("src/types.jl")

cotokentest = coTokenObject()
cotokentest.tokenName = "inheritance"
cotokentest.tokenCoefficient = 1
println(cotokentest)

# dictionary
symbol_conversion_dict = Dict{String,String}()
symbol_conversion_dict["ab"] = "cd"
symbol_conversion_dict["fg"] = "hi"

# Set{String}
reservedWords = Set{String}(["tag","jljl"])
println(in("tag", reservedWords))
# Array{Any,1}
problem_tokens_array = Array{Any,1}()
push!(problem_tokens_array, "ljlj")
push!(problem_tokens_array, cotokentest)
push!(problem_tokens_array, symbol_conversion_dict)

# push! append!
error_while_tokenizing_sentence = Array{errorObject,1}()
tmp_tokenized_error_array = Array{errorObject,1}()
aa = errorObject()
bb = errorObject()
push!(tmp_tokenized_error_array, aa, bb)
append!(error_while_tokenizing_sentence, tmp_tokenized_error_array)


actor_token_array = Array{TokenObject,1}[]
tmp_actor_token_array = Array{TokenObject,1}()
cc = TokenObject()
dd = TokenObject()
ee = TokenObject()
push!(tmp_actor_token_array, cc, dd, ee)
@show length(tmp_actor_token_array)

# arguments of a funtion --> if parsed a mutable variable, parse by share the value
function parsepointer(x::Int, qtmp_actor_token_array::Array{TokenObject,1})
  x = x+1
  ff = TokenObject()
  push!(qtmp_actor_token_array, ff)
end
xyz = 5
parsepointer(xyz, tmp_actor_token_array)
@show length(tmp_actor_token_array)
@show xyz
# length of empty is zero.
symbol_conv_grammar_error = errorObject[]
@show length(symbol_conv_grammar_error)

tststring = "aljljle jljet or and & m |l  , x "
splitstring = split(tststring, r"or|\|")
splitstring = split(tststring, r"and|&|,")
@show splitstring

# change string to float
@show typeof(get(tryparse(Float64, "10.1")))

@show collect(search("jljlj_jljl;", r"[_|;]"))

# a new stirng? aa[2:end] gives rise a new string, also new index
aa = "jlqyitp"
collect(search(aa[2:end], "qy"))

a = collect(1:0)
println(isempty(a+10))
isempty(10+collect(search("jljljljlj", "KKK")))
