# NML_GBMGenerator
Natural modeling language for general biological model generation
To generate a GRN model, issue the command ```julia make_julia_model.jl``` from the command line (outside of the REPL).
or
issue the command ```include("julia make_julia_model.jl")``` in the REPL from the command line.


